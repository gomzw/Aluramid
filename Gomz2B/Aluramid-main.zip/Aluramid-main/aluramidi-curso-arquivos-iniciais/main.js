function tocaSomPom () {
   document.querySelector('#som_tecla_pom')


}

 document.querySelector('.tecla_pom');